package com.example.LoginTest.core.account.joinAndLogin.dto;

import lombok.Data;

@Data
public class LoginRequestDto {
    private String username;
    private String password;
}
