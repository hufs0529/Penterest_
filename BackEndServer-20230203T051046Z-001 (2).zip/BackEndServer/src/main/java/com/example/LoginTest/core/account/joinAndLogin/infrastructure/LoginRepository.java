package com.example.LoginTest.core.account.joinAndLogin.infrastructure;//package penterest_spring.demo.core.account.infrastructure;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//import penterest_spring.demo.core.account.domain.UserInfo;
//
//import java.util.Optional;
//
//@Repository
//public interface LoginRepository extends JpaRepository <UserInfo, Long> {
//    Optional<UserInfo> findByUsername(String UserName); // UserID로 회원 검색
//}
